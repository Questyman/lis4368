See example README.md screenshots in Blackboard > Assignments.
