JDK and Tomcat installation screenshots in this folder.

(See index.jsp code.)
